document.querySelectorAll('[data-reveal-target]').forEach((button)=>{
  button.addEventListener('click',()=>{
    const target=document.querySelector(button.dataset.revealTarget);
    if(!target) return;
    target.classList.remove('d-none');
    target.scrollIntoView({behavior:'smooth', block:'start'});
  });
});

document.querySelectorAll('[data-rating-group]').forEach((group)=>{
  const stars=[...group.querySelectorAll('button')];
  stars.forEach((button,index)=>{
    button.addEventListener('click',()=>{
      stars.forEach((star,i)=>star.classList.toggle('active',i<=index));
    });
  });
});

document.querySelectorAll('[data-sort-reviews]').forEach((button)=>{
  button.addEventListener('click',()=>{
    const list=document.querySelector(button.dataset.sortReviews);
    if(!list) return;
    const reviews=[...list.querySelectorAll('[data-review-rating]')];
    const desc=button.dataset.order!=='desc';
    reviews.sort((a,b)=> desc ? Number(b.dataset.reviewRating)-Number(a.dataset.reviewRating) : Number(a.dataset.reviewRating)-Number(b.dataset.reviewRating));
    reviews.forEach(r=>list.appendChild(r));
    button.dataset.order=desc?'desc':'asc';
    button.textContent=desc?'Sort: highest first':'Sort: lowest first';
  });
});

const contactForm=document.querySelector('#contact-form');
if(contactForm){
  contactForm.addEventListener('submit',(event)=>{
    event.preventDefault();
    const alertBox=document.querySelector('#contact-alert');
    if(alertBox){
      alertBox.classList.remove('d-none');
      alertBox.focus();
    }
    contactForm.reset();
  });
}